<?PHP
  
  echo(45  == 45.0); echo("<BR>"); // Resultado: 1
  echo(45 === 45.0); echo("<BR>"); // Resultado: <branco, vazio>
  echo(5 < 5);       echo("<BR>"); // Resultado: <branco, vazio>
  echo(5 >= 5);      echo("<BR>"); // Resultado: 1
  
?>
