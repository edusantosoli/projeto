<?PHP
 
  $meuArray = array('Alpha', 'Beta', 'Gama');
  $minhaString = implode(' - ', $meuArray);
  echo($minhaString);
  // Resultado: Alpha - Beta - Gama 
 
?>
