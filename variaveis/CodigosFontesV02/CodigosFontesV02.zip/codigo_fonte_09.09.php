<?PHP
 
  if($_REQUEST["action"] == "save")
  {
    $formValid = TRUE;
  }
  
?>
