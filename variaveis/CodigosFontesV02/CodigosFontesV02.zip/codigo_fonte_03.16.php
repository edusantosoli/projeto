<?PHP
 
  echo(trim('   Brasil   penta   campeao   ').'<BR>');
  // Resultado: _Brasil   penta   campeao_
  
  echo(ltrim('   Brasil   penta   campeao   ').'<BR>');
  // Resultado: _Brasil   penta   campeao   _
  
  echo(rtrim('   Brasil   penta   campeao   ').'<BR>');
  // Resultado: _   Brasil   penta   campeao_
 
?>
