<?PHP
 
  $valor = 15.3;
  
  echo "".(float)$valor."<BR>";
  echo "".(int)$valor."<BR>";
  echo "".(bool)$valor."<BR>";
   
  /* RESULTADO
  * 
  * 15.3
  * 15
  * 1
  *   
  */  
 
?>
