<?PHP
 
  include("dados.txt");
  header("Location: http://www.google.com.br");
  
?>
