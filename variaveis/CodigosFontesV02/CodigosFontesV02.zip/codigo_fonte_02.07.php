<?PHP
  
  define("minhaConstanteA", "Brasil");
  echo minhaConstanteA .'<BR>'; // Resultado: Brasil
  echo MINHACONSTANTEA .'<BR>'; // Resultado: MINHACONSTANTEA
    
  define("minhaConstanteB", "Brasil", TRUE);
  echo minhaConstanteB .'<BR>'; // Resultado: Brasil
  echo MINHACONSTANTEB .'<BR>'; // Resultado: Brasil
 
?>
