<?PHP
 
  if(isset($minhaVar))
    echo "A vari�vel est� definida (primeiro if)";
 
  $minhaVar = "";
 
  if(isset($minhaVar))
    echo "A vari�vel est� definida (segundo if)";
 
?>
