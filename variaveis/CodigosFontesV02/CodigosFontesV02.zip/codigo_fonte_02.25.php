<?PHP
  
  $meuValor = 'Brasil';
  echo($meuValor.'<BR>'); // Resultado: Brasil
  
  include 'codigo_fonte_02.24.php';
  
  echo($meuValor.'<BR>'); // Resultado: It�lia
 
?>
