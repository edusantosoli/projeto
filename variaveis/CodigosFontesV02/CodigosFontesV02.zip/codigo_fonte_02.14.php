<?PHP
  
  $meuArray = array('a', 'b', 'c', 'd');
  
  foreach($meuArray as $valor)
  {
    echo($valor .' '); // Resultado: a b c d 
  }
  
?>
