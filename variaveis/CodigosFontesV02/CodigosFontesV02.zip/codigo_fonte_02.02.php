<HTML>
  <BODY>
    <INPUT type=text value='
      <?PHP
        
        echo("Hello World!");
        // Resultado na caixa de texto: Hello World!
        
      ?>
    '>
  </BODY>
</HTML>
