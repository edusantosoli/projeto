<?PHP
 
  echo('C�digo iniciando...<BR>');
  goto saindo;
  
  echo('C�digo executando...<BR>');
   
saindo:
  echo('C�digo encerrando...<BR>');
 
?>
