<?PHP
 
  $meuValor = 'It�lia';
  
?>
