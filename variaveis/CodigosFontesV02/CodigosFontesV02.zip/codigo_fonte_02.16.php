<?PHP
  
  $i = 0;
  
  do
  {
    echo($i .' '); // Resultado: 0 1 2 3 4 
    $i++;
  }
  while($i < 5);
  
?>
