<?PHP
  
  if(3 > 5)
    echo('N�o entra no primeiro if. ');
    
  if(1 < 10)
    echo('Entra no segundo if. ');
  else
    echo('N�o entra no else do segundo if. ');
    
  $i = 5;
  if($i == 3)
  {
    echo('O valor de i � 3.');
  }
  else if($i == 4)
  {
    echo('O valor de i � 4.');
  }
  else
    echo('O valor de i n�o � 3 nem 4.');
  
?>
