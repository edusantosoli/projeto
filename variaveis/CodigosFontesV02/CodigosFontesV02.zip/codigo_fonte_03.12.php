<?PHP
 
  $resultado = str_split("Brasil penta campeao");
  echo($resultado[1].'<BR>');
  // Resultado: r
  
  $resultado = str_split("Brasil penta campeao", 3);
  echo($resultado[1].'<BR>');
  // Resultado: sil
  
?>
