INSERT INTO ENQUETES (ENQUETE) VALUES 
('Qual o tema de PHP que voc� gostaria de realizar um treinamento?');
 
SELECT ID FROM ENQUETES 
WHERE ENQUETE = 'Qual o tema de PHP que voc� gostaria de realizar um treinamento?';
