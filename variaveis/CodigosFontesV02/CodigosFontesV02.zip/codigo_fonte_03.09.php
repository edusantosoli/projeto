<?PHP
  
  echo(strtolower('andre MILANI').'<BR>');
  // Resultado: andre milani
  
  echo(strtoupper('andre MILANI').'<BR>');
  // Resultado: ANDRE MILANI
  
  echo(ucfirst('andre MILANI').'<BR>');
  // Resultado: Andre MILANI
  
?>
