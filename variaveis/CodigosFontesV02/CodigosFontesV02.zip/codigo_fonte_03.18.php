<?PHP
  
  $valor = "15";
  $valor++;
  echo $valor;
  // Resultado: 16
  
?>
