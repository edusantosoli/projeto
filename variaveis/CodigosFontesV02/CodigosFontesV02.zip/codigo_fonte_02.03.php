<?PHP
  
  $minhaVar = "Valor informado";
  echo($minhaVar);
  // Resultado: Valor informado
  
?>
