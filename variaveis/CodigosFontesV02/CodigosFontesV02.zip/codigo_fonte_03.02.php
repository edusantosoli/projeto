<?PHP
 
  $nomePais = 'Brasil';
   
  echo "Pais: $nomePais <BR>";
  // Resultado: Brasil
    
  echo 'Pais: $nomePais <BR>';
  // Resultado: $nomePais
     
  echo 'Pais: '.$nomePais.' <BR>';
  // Resultado: Brasil
 
?>
