INSERT INTO TB_FUNCIONARIOS VALUES(1, 'Andr�', 'P�s-Graduado', 'Analista de Neg�cios', 1000);
INSERT INTO TB_FUNCIONARIOS VALUES(2, 'Cl�udio', 'Mestre', 'Analista de Sistemas', 2000);
INSERT INTO TB_FUNCIONARIOS VALUES(3, 'Luis', 'Graduado', 'Analista de Sistemas', 700);
INSERT INTO TB_FUNCIONARIOS VALUES(4, 'Alfredo', 'P�s-Graduado', 'Analista de BI', 2300);
INSERT INTO TB_FUNCIONARIOS VALUES(5, 'Augusto', 'Doutor', 'Administrador de Banco de Dados', 2600);
INSERT INTO TB_FUNCIONARIOS VALUES(6, 'Ricardo', 'Graduado', 'Analista de Sistemas', 1000);
INSERT INTO TB_FUNCIONARIOS VALUES(7, 'Thais', 'Graduado', 'Analista de Marketing', 1100);
INSERT INTO TB_FUNCIONARIOS VALUES(8, 'Pedro', 'Graduado', 'Programador', 900);
INSERT INTO TB_FUNCIONARIOS VALUES(9, 'Fl�via', 'Mestre', 'Analista de Sistemas', 2300);
