<?PHP
 
  session_start();
  echo "Bem vindo ".$_SESSION["usuario"];
 
?>
