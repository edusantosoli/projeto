<?PHP
  
  echo("Hello World!");
  // Resultado: Hello World!
  
?>
