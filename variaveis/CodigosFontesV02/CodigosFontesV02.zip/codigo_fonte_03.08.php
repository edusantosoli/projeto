<?PHP
  
  echo(chr(65).'<BR>'); 
  // Resultado: A 
  
?>
