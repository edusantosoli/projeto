<?PHP
  
  echo(strrev('Brasil'));
  // Resultado: lisarB 
  
?>
